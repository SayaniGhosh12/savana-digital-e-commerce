import { AlertOctagon, BadgeCheck, Heading2Icon, ShoppingCart } from 'lucide-react'
import React, { useContext } from 'react'
import SkeletonProjectInfo from './SkeletonProjectInfo'
import { useUser } from '@clerk/nextjs'
import { useRouter } from 'next/navigation';
import GlobalApi from '../../../_utils/GlobalApi'
import { CartContext } from '../../../_context/CartContext';

function ProjectInfo({ product }) {

  const{user}=useUser();
  const router=useRouter();
  const {cart,setCart}=useContext(CartContext);
  const onAddToClick=()=>{
    if(!user){
      router.push('/sign-in')
      return;
    }
    else{
      // add to cart
      const data={
        data:{
          userName:user.fullName,
          email:user.primaryEmailAddress.emailAddress,
          products:product?.id
        }
      }

      GlobalApi.AddToCart(data).then(resp=>{
        console.log("Add to Cart",resp);
        if(resp){
        setCart(cart=>[...cart,
          {
            id:resp?.data?.id,
            product:product
          }

          
        
        ])
      }
      },(error)=>{
        console.log('Error',error)
      })
    }
  }

  return (
    <div>
     {product ? <div>
        <h2 className='text-[20px]'>
          {product?.attributes?.title}
        </h2>
        <h2 className='text-[15px] text-gray-400'>
          {product?.attributes?.category}
        </h2>
        <h2 className='text-[20px] text-gray-700 mt-5'>
          {product?.attributes?.description?.map((item, index) => (
            <p className='text-[20px] text-gray-700' key={index}>{item.children.map((child, childIndex) => child.text).join(' ')}</p>
          ))}
        </h2>
        <h2 className='flex gap-2 mt-5 text-gray-700 text-[13px]'>
          {product?.attributes?.InstantDelivery ? <BadgeCheck className='text-green-500 h-5 w-5' /> : <AlertOctagon className='text-yellow-400 h-5 w-5' />}
          Eligible for Instant Delivery
        </h2>
        <h2 className='text-[35px] mt-5 text-primary font-medium'>
          Rs {product?.attributes?.pricing}
        </h2>
        <button className='flex gap-2 p-4 bg-primary text-white rounded-lg px-10 mt-5  hover:bg-blue-700' onClick={() => onAddToClick()}>
          <ShoppingCart />
          Add to Cart
        </button>
      </div>:
      <SkeletonProjectInfo />}
    </div>
  )
}

export default ProjectInfo