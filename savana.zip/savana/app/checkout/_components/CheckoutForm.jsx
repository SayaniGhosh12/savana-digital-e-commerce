import { PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import React, { useContext, useState } from 'react';
import GlobalApi from '../../_utils/GlobalApi';
import { useUser } from '@clerk/nextjs';
import { CartContext } from '../../_context/CartContext';

function CheckoutForm({amount}) {
  const stripe = useStripe();
  const elements = useElements();
  const {cart,setCart}=useContext(CartContext)
  const {user}=useUser();
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState();
  const [loading, setLoading] = useState(false);

  const handleError = (error) => {
    setLoading(false);
    setErrorMessage(error.message);
  }

  const handleSubmit = async (event) => {
    // We don't want to let default form submission happen here,
    // which would refresh the page.
    event.preventDefault();

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
    },2000)

    if (!stripe) {
      // Stripe.js hasn't yet loaded.
      // Make sure to disable form submission until Stripe.js has loaded.
      return;
    }

    setLoading(true);

    // Trigger form validation and wallet collection
    const {error: submitError} = await elements.submit();
    if (submitError) {
      handleError(submitError);
      return;
    }
    createOrder();
    sendEmail();
    

    // Create the PaymentIntent and obtain clientSecret
    const res = await fetch("/api/create-intent", {
      method: "POST",
      body:JSON.stringify({
        amount:amount
      })
    });

    const clientsecret = await res.json();

    // Confirm the PaymentIntent using the details collected by the Payment Element
    const {error} = await stripe.confirmPayment({
      elements,
      clientSecret:clientsecret,
      confirmParams: {
        return_url: '',
      },
    });

    if (error) {
      // This point is only reached if there's an immediate error when
      // confirming the payment. Show the error to your customer (for example, payment details incomplete)
      handleError(error);
    } else {
      // Your customer is redirected to your `return_url`. For some payment
      // methods like iDEAL, your customer is redirected to an intermediate
      // site first to authorize the payment, then redirected to the `return_url`.
    }
  };

  const createOrder = () => {
    let productIds = [];
    
    cart.forEach(element => {
      productIds.push(element?.product?.id);

    });
    const data = {
      email: user.primaryEmailAddress.emailAddress,
      userName: user.fullName,
      amount: amount,
      products: productIds,
     
    };
    console.log(data)
    GlobalApi.createOrder(data).then(resp=>{
      if(resp){
        cart.forEach(element => {
          GlobalApi.deleteCartItem(element.id).then(result=>{

          })
        });
      }
    })
  }

  const sendEmail=async()=>{
    const res = await fetch("/api/send", {
      method: "POST",
      body:JSON.stringify({
        amount:amount,
        email:user.primaryEmailAddress.emailAddress,
        fullName:user.fullName,
      })
    });
  }

  

  return (
    <form onSubmit={handleSubmit} className='bg-white h-screen flex flex-col justify-center items-center'>
      <h1 className='text-3xl  font-bold mb-4 text-black  note-box'>CHECKOUT</h1>
      <div className='w-full md:max-w-[600px] p-8 bg-white'>
        <PaymentElement className='bg-white' />
        <button
          className='bg-primary p-2 text-white rounded-lg w-full mt-6 hover:bg-blue-700 '
          type='submit'
          disabled={isLoading} // Disable the button when loading
        >
          {isLoading ? (
            <div className="loader flex flex-col justify-center items-center "></div>
          ) : (
            'Submit'
          )}
        </button>
      </div>
    </form>
  );
}

export default CheckoutForm;
