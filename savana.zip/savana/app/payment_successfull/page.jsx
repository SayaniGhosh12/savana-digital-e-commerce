"use client"
import React from 'react';
import { useRouter } from 'next/navigation';
import CheckmarkAnimation from './_components/CheckmarkAnimation';

function Page() {
  const router = useRouter();

  const handleGoToHome = () => {
    router.push('/');
  };

  return (
    <div className="payment-successful">
      <div className='py-20'>
      <CheckmarkAnimation />
      </div>
        
        <h1>Payment Successful</h1>
        <p>We sent an email with your order confirmation along with Digital Content</p>
        <button onClick={handleGoToHome}>Go to Home</button>
      
    </div>
  );
}

export default Page;
