// CheckmarkAnimation.js
import React, { useEffect } from 'react';
import anime from 'animejs';

const CheckmarkAnimation = () => {
  useEffect(() => {
    const logoTimeline = anime.timeline({ autoplay: true, direction: 'alternate', loop: true });

    logoTimeline
      .add({
        targets: '.checkmark',
        translateY: [
          { value: [-10, 0], duration: 400, easing: 'easeOutQuad' }, // Move up by 10 units
        ],
        scale: [
          { value: [0, 2], duration: 600, easing: 'easeOutQuad' }, // Increase the scale value to make it bigger
        ],
      })
      .add({
        targets: '.check',
        strokeDashoffset: {
          value: [anime.setDashoffset, 0],
          duration: 700,
          delay: 200,
          easing: 'easeOutQuart',
        },
        translateX: {
          value: [6, 0],
          duration: 700,
          delay: 200,
          easing: 'easeOutQuart',
        },
        translateY: {
          value: [-2, 0],
          duration: 700,
          delay: 200,
          easing: 'easeOutQuart',
        },
        offset: 0,
      });
  }, []);

  return (
    <svg className="checkmark" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 32 32">
      <circle className="circle" cx="16" cy="16" r="16" fill="#008000" />
      <path className="check" d="M9 16l5 5 9-9" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
};

export default CheckmarkAnimation;
