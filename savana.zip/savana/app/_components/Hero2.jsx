import React from 'react'

function Hero2() {
  return (
    <div>Hero2</div>
  )
}

export default Hero2