const { default: axios } = require("axios");

const apikey=process.env.NEXT_PUBLIC_REST_API_KEY
const apiUrl='https://psychic-telegram-q7q9545jjgpw2x45g-1337.app.github.dev/api';

const axiosClient=axios.create({
    baseURL:apiUrl,
    headers:{
        Authorization:`Bearer ${apikey}`
    }
})

const getLatestProducts=()=>axiosClient.get('/products?populate=*');

const getProductById=(id)=>axiosClient.get('/products/'+id+'?populate=*')

const getProductByCategory=(category)=>axiosClient.get('/products?filters[category][$eq]='+category+"&populate=*")

const AddToCart=(data)=>axiosClient.post('/carts',data)

const GetUserCartItems=(email)=>axiosClient.get('/carts?populate[products][populate][0]=banner&filters[email][$eq]='+email)

const deleteCartItem=(id)=>axiosClient.delete('/carts/'+id)

const createOrder=(data)=>axiosClient.post('/orders',data)

export default{
    getLatestProducts,
    getProductById,
    getProductByCategory,
    AddToCart,
    GetUserCartItems,
    deleteCartItem,
    createOrder
}