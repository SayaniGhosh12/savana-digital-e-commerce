import Image from "next/image";
import Hero from "./_components/Hero";
import ProductSection from "./_components/ProductSection";
import Footer from "./_components/Footer";

export default function Home() {
  return (
    <div>
      <Hero />
      {/* latest product section */}
      {/* <ProductSection /> */}
      {/* project source code */}
      {/* <Footer /> */}
      {/* icons pack */}
    </div>
  );
}
