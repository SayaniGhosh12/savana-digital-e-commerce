import {
  Body,
  Button,
  Container,
  Column,
  Head,
  Heading,
  Html,
  Img,
  Preview,
  Row,
  Section,
  Text,
} from "@react-email/components";
import * as React from "react";

const paragraph = {
  fontSize: 16,
};

const logo = {
  padding: "30px 20px",
};

const btnContainer = {
  display: "flex",
  justifyContent: "center",
  width: "100%",
};

const main = {
  backgroundColor: "#fff",
  fontFamily:
    '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif',
};



export const EmailTemplate=({
  body,
}) => (
  <Html>
    <Head />
    <Preview>
      The sales intelligence platform that helps you uncover qualified leads.
    </Preview>
    <Body style={main}>
      <Container>
        <Img
          src=''
          width='240'
          height='50'
          alt="hi"
          style={logo}
        />
        <Text style={paragraph}>
          Hi {body.fullName},
        </Text>
        <Text style={paragraph}> 
          Thank you purchasing on SAVANA. Click on Below download button to download the all digital content
        </Text>
        <Section style={btnContainer}>
          <Button pX={12} pY={12} style={{padding:5, paddingLeft:10, paddingRight:10}} href="https://res.cloudinary.com/ds5gyinon/raw/upload/v1706175475/ATM_9e07b8d2ae.java">
            Download
          </Button>
        </Section>
        <Text>
          best regards,
          <br/>
          Team, SAVANA
        </Text>
      </Container>
    </Body>
  </Html>
)